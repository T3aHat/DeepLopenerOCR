# DeepLopenerPROEXE(Chrome extension)
DeepLopenerPROEXEを使用するのに必要なGoogle Chrome 拡張機能．  
主に
* 閉じたウィンドウを再度開いて`minimized`するため
* 右上の
<img src="https://github.com/T3aHat/DeepLopenerPROEXE/raw/main/assets/cancel.png" width="16px" height="16px">
を押してウィンドウを閉じてプロセスを終了させるため  

に用いられる．