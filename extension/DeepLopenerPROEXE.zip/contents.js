document.querySelector(".message").textContent = "extension installed!";
chrome.runtime.sendMessage({ message: "get_windowid" }, function (res) {
  if (chrome.runtime.lastError) {
  }
  windowid = res;
  const messageDOM = document.querySelector(".message");
  const observer = new MutationObserver((records) => {
    if (messageDOM.textContent == "minimize") {
      messageDOM.textContent = "";
      chrome.runtime.sendMessage({ message: "minimize" }, function (res) {
        if (chrome.runtime.lastError) {
        }
      });
    } else if (messageDOM.textContent == "translating...") {
      chrome.runtime.sendMessage(
        { message: "active", windowid: windowid },
        function (res) {
          if (chrome.runtime.lastError) {
          }
        }
      );
    } else if (messageDOM.textContent == "close") {
      messageDOM.textContent = "";
      chrome.runtime.sendMessage(
        { message: "close", winid: windowid },
        function (res) {
          if (chrome.runtime.lastError) {
          }
        }
      );
    }
  });
  observer.observe(messageDOM, {
    characterData: true,
    attributes: true,
    childList: true,
  });
});
